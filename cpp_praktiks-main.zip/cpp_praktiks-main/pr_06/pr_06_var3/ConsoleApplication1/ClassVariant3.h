#pragma once
class ClassVariant3
{
};

