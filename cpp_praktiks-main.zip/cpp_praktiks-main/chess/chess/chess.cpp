﻿#include <iostream>
#include "Figure.h"
using namespace std;

int main()
{
    setlocale(LC_ALL, "Russian");
    cout << "Игра в шахматы\n";
    Figure *fig1 = new Figure();
    int coordMas[8][8];
    //Пешка слон и ферзь

}

