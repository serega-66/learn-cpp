#pragma once
#include <iostream>
using namespace std;

class ChessBoard
{
public:
    int lx, ly;
    ChessBoard() {
        lx = 8;
        ly = 8;
    }
};

