#pragma once
class Sounds
{
	void playSound() {

	}
};

